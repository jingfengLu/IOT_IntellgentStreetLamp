#include "bsp.h"


RTC_HandleTypeDef hrtc;

Calendar_Str calendar;

/**
 * @description		: RTC��ʼ��
 * @param 			: void
 * @return 			: void
 */
void bsp_InitRtc(void)
{
  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */
	__HAL_RCC_PWR_CLK_ENABLE();
	HAL_PWR_EnableBkUpAccess();
	HAL_PWREx_EnableBkUpReg();/* ʹ�ܱ��ݼĴ��� �������°����������*/
	if (HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR0) == 0x5050) { /* ���ǵ�һ���ϵ� */
		HAL_PWREx_DisableBkUpReg();
//		HAL_PWR_DisableBkUpAccess();
		__HAL_RCC_PWR_CLK_DISABLE();
		return;
	}
	HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR0, 0x5050); //д�뱸�ݼĴ���
  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 0;
  sTime.Minutes = 0;
  sTime.Seconds = 0;
  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
  {
    Error_Handler();
  }
  sDate.WeekDay = RTC_WEEKDAY_MONDAY;
  sDate.Month = RTC_MONTH_JANUARY;
  sDate.Date = 1;
  sDate.Year = 0;

  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN) != HAL_OK)
  {
    Error_Handler();
  }

}


/**
 * @description		: ��ȡRTCʱ��
 * @param 			: void
 * @return 			: void
 */
void Rtc_GetCalendar(void)
{
	RTC_TimeTypeDef RTC_TimeStruct = {0};
	RTC_DateTypeDef RTC_DateStruct = {0};
	
	HAL_RTC_GetTime(&hrtc, &RTC_TimeStruct, RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&hrtc, &RTC_DateStruct, RTC_FORMAT_BIN);
	
	calendar.year   = RTC_DateStruct.Year + 2000;
	calendar.month  = RTC_DateStruct.Month;
	calendar.date   = RTC_DateStruct.Date;
	calendar.hour   = RTC_TimeStruct.Hours;
	calendar.min    = RTC_TimeStruct.Minutes;
	calendar.sec    = RTC_TimeStruct.Seconds;
    calendar.week   = RTC_DateStruct.WeekDay;
    if (calendar.week == RTC_WEEKDAY_SUNDAY)
        calendar.week = 0;
}
/*
 * @description		: ����RTCʱ��
 * @param 			  : void
 * @return 			  : void
 */
static void RTC_Set_Time(uint8_t hour, uint8_t min, uint8_t sec, uint8_t ampm)
{
	RTC_TimeTypeDef RTC_TimeTypeInitStructure = {0};
	
	RTC_TimeTypeInitStructure.Hours=hour;
	RTC_TimeTypeInitStructure.Minutes=min;
	RTC_TimeTypeInitStructure.Seconds=sec;
	RTC_TimeTypeInitStructure.TimeFormat=ampm;
    RTC_TimeTypeInitStructure.DayLightSaving = 
    RTC_TimeTypeInitStructure.StoreOperation = 
    
	HAL_RTC_SetTime(&hrtc, &RTC_TimeTypeInitStructure, RTC_FORMAT_BIN);
}
/*
 * @description		: ����RTC����
 * @param 			  : void
 * @return 			  : void
 */
static void  RTC_Set_Date(uint8_t year, uint8_t month, uint8_t date, uint8_t week)
{
	RTC_DateTypeDef RTC_DateTypeInitStructure = {0};
    
	RTC_DateTypeInitStructure.Date=date;
	RTC_DateTypeInitStructure.Month=month;
    if (week == 0) { /* �����Ļ0��ʾ������ */
        RTC_DateTypeInitStructure.WeekDay = RTC_WEEKDAY_SUNDAY;
    } else {
       RTC_DateTypeInitStructure.WeekDay = week; 
    }
	RTC_DateTypeInitStructure.Year=year;
	HAL_RTC_SetDate(&hrtc, &RTC_DateTypeInitStructure, RTC_FORMAT_BIN);
}
/**
 * @description		: ����RTCʱ������
 * @param 			: ʱ��ṹ��
 * @return 			: void
 */
void Rtc_SetCalendar(Calendar_Str *cale)
{
    if ((!cale) && (cale->year < 2000))
        return;
    
	if (cale->hour > 12)
		RTC_Set_Time(cale->hour, cale->min, cale->sec, RTC_HOURFORMAT12_PM);
	else
		RTC_Set_Time(cale->hour, cale->min, cale->sec, RTC_HOURFORMAT12_AM);
	RTC_Set_Date(cale->year - 2000, cale->month, cale->date, cale->week);
    
    if (cale != &calendar)
        memcpy(&calendar, cale, sizeof(calendar));
}


/**
 * @description		: ��ȡ��ǰ��Unixʱ���
 * @param 			: void
 * @return 			: 0ʧ�� �����ɹ�
 */
time_t Rtc_GetUnixTime(void)
{
    struct tm local_time = {0};
    
    if (calendar.year < 1900)
        return 0;
    local_time.tm_year = calendar.year - 1900;
    local_time.tm_mon = calendar.month - 1;
    local_time.tm_mday = calendar.date;
    local_time.tm_hour = calendar.hour;
    local_time.tm_min = calendar.min;
    local_time.tm_sec = calendar.sec;
    local_time.tm_isdst = 0;
    return mktime(&local_time) - 28800; //��ȥ8��Сʱ����8����0����8��Сʱ
}




