#include "bsp.h"
#include "cmsis_os2.h"
#include "token.h"
#include "save.h"
#include "light_con.h"
#include "dev_info.h"

//#define ONEJSON_BLANK_CHAR     "\t"    //ʹ���Ʊ�����Ϊjson��������Ķ����ַ�
//#define ONEJSON_LINEBREAK_CHAR "\r\n" //�س���Ϊ���з�


#define ONET_TOKEN_VER          "2018-10-31"
#define ONET_TOKEN_RES          ONET_PRODUCT_ID"/devices/"ONET_DEVICE_NAME

/************** ONE_NET publish���ֵ�topic ****************/
#define ONET_TOPIC_PROPERTY_POST         "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/post"                         /* �豸�����ϱ�                    */
#define ONET_TOPIC_PROPERTY_SET_REPLY    "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/set_reply"                    /* �豸�������ã�ͬ����Ӧ��         */
#define ONET_TOPIC_PROPERTY_DESIRED_GET  "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/desired/get"                  /* �豸��ȡ��������ֵ               */
#define ONET_TOPIC_PROPERTY_DESIRED_DEL  "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/desired/delete"               /* �����������ֵ                   */
#define ONET_TOPIC_PROPERTY_GET_REPLY    "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/get_reply"                    /* �豸���Ի�ȡӦ��                 */
#define ONET_TOPIC_EVENT_POST            "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/event/post"                            /* �豸�¼��ϱ�                     */
#define ONET_TOPIC_SERVICE_INVOKE_REPLY  "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/service/%s/invoke_reply"               /* �豸�������Ӧ�� %s��ʾidentifier */                                       
/************** ONE_NET subscribe���ֵ�topic ****************/
#define ONET_TOPIC_PROPERTY_POST_REPLY   "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/post/reply"                   /* �豸�����ϱ�Ӧ��            */
#define ONET_TOPIC_PROPERTY_SET          "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/set"                          /* �豸��������                */
#define ONET_TOPIC_PROPERTY_DES_GET_REP  "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/get/reply"                    /* �豸����ֵ��ȡӦ��           */
#define ONET_TOPIC_PROPERTY_DES_DEL_REP  "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/delete/reply"                 /* �豸����ֵ���Ӧ��           */
#define ONET_TOPIC_PROPERTY_GET          "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/property/get"                          /* �豸���Ի��                 */                                        
#define ONET_TOPIC_EVETN_POST_REPLY      "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/event/post/reply"                      /* �豸�¼��ϱ�Ӧ��              */  
#define ONET_TOPIC_SERVICE_INNVOKE       "$sys/"ONET_PRODUCT_ID"/"ONET_DEVICE_NAME \
                                         "/thing/service/%s/invoke"                     /* �豸������� %s��ʾidentifier */ 

/************** ONENET��MQTT������� ���״̬�� ****************/
#define ONENET_MQTTCODE_SUC             200
#define ONENET_MQTTCODE_THINGERR        1002 //��ģ�ʹ���
                                         
#define BC28_TEST_CMD           "AT"           //��������
#define BC28_REBOOT_CMD         "AT+NRB"       //ģ����������
#define BC28_QREGSWT_CMD        "AT+QREGSWT=2" //��ֹ��Ϊ�� �ϵ���һʱ�䷢��
#define BC28_GETCSQ_CMD         "AT+CSQ"       //����ź�ǿ��
#define BC28_GETIP_CMD          "AT+CGPADDR"   //��ȡģ���ip��ַ
#define BC28_UDP_CREAT_CMD      "AT+NSOCR=DGRAM,17,8855,1" //����UDP SCOKET����
#define BC28_UDP_SEND_CMD       "AT+NSOST=2,"NTP_SERVER_IP",48," \
                                "E30006EB000000000000000000000000000"\
                                "000000000000000000000000000000000000"\
                                "0000000000000000000000000,100"
#define BC28_UDP_REC_CMD        "AT+NSORF=2,100" //��������

#define BC28_MQTTCFG_CMD        "AT+QMTCFG=\"version\",0,4" //�л�Э��汾
#define BC28_MQTTOPEN_ONT_CMD   "AT+QMTOPEN=0,\"studio-mqtt.heclouds.com\",1883" //����one������
#define BC28_MQTTCONN_ONT_CMD   "AT+QMTCONN=0,\"%s\",\"%s\",\"%s\""
#define BC28_MQTTPUB_CMD        "AT+QMTPUB=0,0,0,0,\"%s\""            //publish������%s������дtopic
#define BC28_MQTTSUB_CMD        "AT+QMTSUB=0,1,\""ONET_TOPIC_PROPERTY_SET"\",1" //��Ҫ����topic


 
#define BC28_DELAYMS(X) osDelay(X)



static bc28_info_str bc28_info;
static uint32_t post_id;



/**
 * @description	  : BC28��������
 * @param     	  : ����
 * @param     	  : ���ݳ���
 * @return 		  : void
 */
static void Bc28_SendData(uint8_t *data, size_t size)
{
    At_SendData(data, size);
}

/**
 * @description	  : BC28����һ���ַ���
 * @param     	  : �ַ���
 * @return 		  : void
 */
static void Bc28_SendStr(char *str)
{
    At_SendStr(str);
}

/**
 * @description	  : BC28����һ��ָ��
 * @param     	  : ָ���ַ���
 * @return 		  : void
 */
static void Bc28_SendCmd(char *cmd)
{
    At_SendCmd(cmd);
}

/**
 * @description	  : BC28�ȴ���Ӧ
 * @param     	  : �ȴ���Ӧ���ַ���
 * @param     	  : ��ʱʱ��
 * @return 		  : 0��Ӧʧ�� 1��Ӧ�ɹ�
 */
static uint8_t Bc28_WaitResponse(char *ack, uint16_t timeout)
{
    return At_WaitResponse(ack, timeout);
}

/**
 * @description	  : BC28��ȡ�ź�ǿ��
 * @param     	  : ���Դ���
 * @param     	  : ���Լ��ʱ��
 * @return 		  : 0�źŴ��� 1�ź�����
 */
static uint8_t Bc28_GetCSQ(uint8_t retry, uint16_t time)
{
    uint16_t ret;
    char buf[24], num[3];
    char* p;
    int sig;
    
    
    do {
        Bc28_SendCmd(BC28_GETCSQ_CMD);
        while (1) {
            ret = At_ReadLine(buf, 24, time);
            if (ret) {
                ret = 0;
                if (strstr(buf, "+CSQ")) {
                    p = strchr(buf, ':');
                    if (p) {
                        p++;
                        num[0] = p[0];
                        num[1] = p[1];
                        num[2] = 0;
                        sig = atoi(num);
                        if (sig && sig != 99) {
                            bc28_info.sig = sig;
                            ret = 1;
                            break;
                        }
                    }
                }
            } else break; 
        }
    } while (retry-- && ret == 0);

    return ret;
}

/**
 * @description	  : BC28��ȡip
 * @param     	  : ���Դ���
* @param     	  : ���Լ��ʱ�� unit:ms
 * @return 		  : 0ip���� 1ip����
 */
static uint8_t Bc28_GetIP(uint8_t retry, uint16_t time)
{
    uint8_t ret;
    char buf[32], *p, *token;
    
    do {
        Bc28_SendCmd(BC28_GETIP_CMD);
        while (1) {
            ret = At_ReadLine(buf, sizeof(buf), time);
            if (ret) { /* ��ȡ�ɹ� */
                ret = 0;
                if (strstr(buf, "+CGPADDR")) { /* �ɹ���Ӧ */
                    p = strchr(buf, ',');
                    if (p) { /* �������ip��ַ */
                        p++;//����','
                        token = strtok(p, ".");
                        bc28_info.ip4[0] = atoi(token);
                        token = strtok(NULL, ".");
                        bc28_info.ip4[1] = atoi(token);
                        token = strtok(NULL, ".");
                        bc28_info.ip4[2] = atoi(token);
                        token = strtok(NULL, ".");
                        bc28_info.ip4[3] = atoi(token);
                        ret = 1;
                        break;
                    }
                }
            } else break; //��ʱ
        }
    } while (retry-- && ret == 0);
    return ret;
}


/**
 * @description	  : BC28��MQTT������
 * @param     	  : ���Դ���
* @param     	  : ���Լ��ʱ�� unit:ms
 * @return 		  : 0ip���� 1ip����
 */
static uint8_t Bc28_MqttOpen(uint8_t retry, uint16_t time)
{
    uint8_t ret;
    char buf[32];
    
    do {
        Bc28_SendCmd(BC28_MQTTOPEN_ONT_CMD);
        while (1) {
            ret = At_ReadLine(buf, sizeof(buf), time);
            if (ret) { /* ��ȡ�ɹ� */
                ret = 0;
                if (strstr(buf, "+QMTOPEN:")) { /* �ɹ���Ӧ */
                    if (strstr(buf, "0,0")) { /* �򿪳ɹ� */
                        ret = 1;
                        break;
                    } else break;
                }
            } else break; //��ʱ
        }
    } while (retry-- && ret == 0);
    return ret;
}

/**
 * @description	  : BC28����MQTT�豸
 * @param     	  : ���Դ���
 * @param     	  : ���Լ��ʱ�� unit:ms
 * @return 		  : 0ip���� 1ip����
 */
static uint8_t Bc28_MqttConn(uint8_t retry, uint16_t time)
{
    uint8_t ret;
    char buf[32], token[160], cmd[220], res[56] = {0};
    
    strcpy(res, ONET_TOKEN_RES);
    if (Token_Authorization(ONET_TOKEN_VER, res, ONET_CONN_ET, ONET_PRODUCT_KEY, token, sizeof(token)))
        return 0;

    snprintf(cmd, sizeof(cmd), BC28_MQTTCONN_ONT_CMD, ONET_DEVICE_NAME, ONET_PRODUCT_ID, token);
    
    At_ClearReceive(); /* ������н��� */
    
    do {
        Bc28_SendCmd(cmd);
        while (1) {
            ret = At_ReadLine(buf, sizeof(buf), time);
            if (ret) { /* ��ȡ�ɹ� */
                ret = 0;
                if (strstr(buf, "+QMTCONN:")) { /* �ɹ���Ӧ */
                    if (strstr(buf, "0,0")) { /* CONNECT�ɹ� */
                        ret = 1;
                        break;
                    } else break;
                } else if (strstr(buf, "ERROR")) { /* ERROR˵��open�Ѿ��Ͽ��ˣ���Ҫ����open */
                    break;
                }
            } else break; //��ʱ
        }
    } while (retry-- && ret == 0);
    return ret;
}


/**
 * @description	  : BC28����ONENET֮����ж���
 * @param     	  : void
 * @return 		  : 0ʧ�� 1�ɹ�
 */
static uint8_t Bc28_MqttSubInit(void)
{
    uint8_t ret;
    char buf[32];
    
    Bc28_SendCmd(BC28_MQTTSUB_CMD);
    while (1) {
        ret = At_ReadLine(buf, sizeof(buf), 5000);
        if (ret) { /* ��ȡ�ɹ� */
            ret = 0;
            if (strstr(buf, "+QMTSUB:")) { /* �ɹ���Ӧ */
                if (strstr(buf, "0,1,0")) { /* CONNECT�ɹ� */
                    ret = 1;
                    break;
                } else break;
            } else if (strstr(buf, "ERROR")) { /* ERROR˵�������Ѿ��Ͽ��ˣ���Ҫ�������� */
                bc28_info.sta.bit.mqtt_conn = 0;
                bc28_info.sta.bit.mqtt_conn = 0;
                break;
            }
        } else break; //��ʱ
    }
    
    return ret;
}

/**
 * @description	  : BC28����ONENET֮����ж���
 * @param     	  : ��Ϣid
 * @param     	  : ���صĽ����
 * @return 		  : 0ʧ�� 1�ɹ�
 */
static void Bc28_MqttProSetReply(uint64_t id, int32_t code)
{
    char cmd[100];
    uint64_t unix_ms;
    uint8_t end_chr = 0x1A;
    
    bc28_info.sta.bit.mqtt_pub = 1; //��ʼpublish
    snprintf(cmd, sizeof(cmd), BC28_MQTTPUB_CMD, ONET_TOPIC_PROPERTY_SET_REPLY);
    Bc28_SendCmd(cmd);
    Bc28_WaitResponse(">", 2000);
    
    Bc28_SendStr("{\r\n");
    snprintf(cmd, sizeof(cmd), "\"id\":\"%llu\",\r\n", id);
    Bc28_SendStr(cmd);
    snprintf(cmd, sizeof(cmd), "\"code\":%d,\r\n", code);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\"msg\":\"no\"\r\n");
    Bc28_SendStr("}\r\n");
    Bc28_SendData(&end_chr, 1); /* ���ͽ����ַ� */
    
    Bc28_WaitResponse("+QMTPUB:", 5000);
    BC28_DELAYMS(100);
    At_ClearReceive(); /* ������н��� */
    
    bc28_info.sta.bit.mqtt_pub = 0;
}


/**
 * @description	  : BC28��λ
 * @param     	  : void
 * @return 		  : void
 */
static void Bc28_Reset(void)
{
    Bc28Rst_OFF();
    BC28_DELAYMS(200);
    Bc28Rst_ON();
}




/**
 * @description	  : BC28�Ƿ�����
 * @param     	  : void
 * @return 		  : 0������ 1����
 */
uint8_t Bc28_IsNormal(void)
{
    if (bc28_info.sta.bit.mqtt_open == 0 || bc28_info.sta.bit.mqtt_conn == 0 || \
        bc28_info.sig == 99) {
        memset(&bc28_info, 0, sizeof(bc28_info));
        return 0;
    }
    return 1;
}

/**
 * @description	  : BC28��ʼ��
 * @param     	  : void
 * @return 		  : void
 */
void Bc28_Init(void)
{
    uint8_t i;
    
    reboot:
    bc28_info.sta.all = 0;
    bc28_info.sig = 99;
    
    do {
        Bc28_SendCmd(BC28_REBOOT_CMD);
//        Bc28_Reset();
    } while (!Bc28_WaitResponse("OK", 10000)); /* 10s��ʱ */
    BC28_DELAYMS(1000);
    
//    Bc28_SendCmd(BC28_TEST_CMD);
    Bc28_SendCmd(BC28_QREGSWT_CMD);
    
    if (!Bc28_WaitResponse("OK", 2000)) {
        goto reboot;
    }
    bc28_info.sta.bit.ready = 1;
    BC28_DELAYMS(1000);
    
    if (Bc28_GetCSQ(5, 5000)) { /* ����5�� ÿ�μ��5s ���ź� */
        bc28_info.sta.bit.sig = 1; /* ���ź� */
        BC28_DELAYMS(10000);
        if (Bc28_GetIP(5, 5000)) { /* �ȴ���ȡIP */
            bc28_info.sta.bit.ip = 1;
            BC28_DELAYMS(5000);
            Bc28_SendCmd(BC28_MQTTCFG_CMD); /* ����Э��汾3.1.1 */
            if (!Bc28_WaitResponse("OK", 2000))
                goto reboot;
            BC28_DELAYMS(7000);
            if (Bc28_MqttOpen(2, 30000)) {
                bc28_info.sta.bit.mqtt_open = 1;
                BC28_DELAYMS(2000);
                if (Bc28_MqttConn(3, 10000)) { /* ���ӳɹ� */
                    bc28_info.sta.bit.mqtt_conn = 1;
                    BC28_DELAYMS(1000);
                    Bc28_MqttSubInit(); //����
                    BC28_DELAYMS(1000);
                    Bc28_SendCmd(BC28_UDP_CREAT_CMD); //����UDP
                    if (Bc28_WaitResponse("OK", 5000)) {
                        bc28_info.sta.bit.udp_creat = 1;
                        if (save_old.timing.power_on) {
                            BC28_DELAYMS(1000);
                            Bc28_GetNtpTime();
                        }
                    }
                } else goto reboot;
            } else goto reboot;
        }
    } else { /* û���źţ����������Ϣ������ʾ */
        bc28_info.sig = 99;
    }
}

/**
 * @description	  : BC28��ȡNTPʱ��
 * @param     	  : void
 * @return 		  : 0��ȡʧ�� 1��ȡ�ɹ�
 */
uint8_t Bc28_GetNtpTime(void)
{
    uint8_t ret, i;
    char buf[200], *p, t[8];
    time_t sec;
    struct tm *local_time;
    Calendar_Str cale;
    
    if (bc28_info.sta.bit.sig == 0 || bc28_info.sta.bit.udp_creat == 0)
        return 0;
    
    At_ClearReceive(); /* ������н��� */
    Bc28_SendCmd(BC28_UDP_SEND_CMD); //����NTP����
    while (1) {
        ret = At_ReadLine(buf, sizeof(buf), 10000);
        if (ret) { /* ��ȡ�ɹ� */
            ret = 0;
            if (strstr(buf, "+NSOSTR:")) { /* �ɹ����� */
                ret = 1;
                break;
            } else if (strstr(buf, "ERROR")) { /* ERROR˵��udp scoket�Ѿ��ر��� */
                bc28_info.sta.bit.udp_creat = 0;
                break;
            }
        } else break; //��ʱ
    }
    if (ret) {
        while (1) {
            ret = At_ReadLine(buf, sizeof(buf), 3000);
            if (ret) {
                ret = 0;
                if (strstr(buf, "+NSONMI:")) {
                    Bc28_SendCmd(BC28_UDP_REC_CMD); //����NTP����
                    ret = 1;
                    break;
                }
            } else break;
        }
    }
    if (ret) {
        while (1) {
            ret = At_ReadLine(buf, sizeof(buf), 3000);
            if (ret) {
                ret = 0;
                if (buf[0] == '2') { /* 2��scoket */
                    p = strtok(buf, ",");
                    while (p[0] != '4' && p[1] != '8') {
                        p = strtok(NULL, ",");
                    }
                    p = strtok(NULL, ",");
                    if (strlen(p) > 90) {
                        for (i = 80; i < 88; i++) {
                            t[i - 80] = p[i] >= 'A' ? p[i] - 'A' + 0xA : p[i] - '0';
                        }
                        sec = t[0] << 28 | t[1] << 24 | t[2] << 20 | t[3] << 16 | \
                              t[4] << 12 | t[5] << 8 | t[6] << 4 | t[7];
                        sec -= 2208960000UL;
                        local_time = localtime(&sec);
                        cale.year = local_time->tm_year + 1900;
                        cale.month = local_time->tm_mon + 1;
                        cale.date = local_time->tm_mday;
                        cale.hour = local_time->tm_hour;
                        cale.min = local_time->tm_min;
                        cale.sec = local_time->tm_sec;
                        cale.week = 1;
                        Rtc_SetCalendar(&cale);
                        bc28_info.sta.bit.ntp_get = 1;
                        return 1;
                    }
                    break;
                }
            } else break;
        }
    }
    return 0;
}



/**
 * @description	  : BC28�ϴ��豸����
 * @param     	  : �¶�
 * @param     	  : ʪ��
 * @param     	  : pm2.5
 * @return 		  : 0ʧ�� 1�ɹ�
 */
uint8_t Bc28_MqttPublish_PropertyPost(int16_t temp, uint16_t humi, uint16_t pm25)
{
    char cmd[100];
    uint64_t unix_ms;
    uint8_t end_chr = 0x1A;
    
    if (bc28_info.sta.bit.mqtt_conn == 0)
        return 0;
    
    bc28_info.sta.bit.mqtt_pub = 1; //��ʼpublish
    snprintf(cmd, sizeof(cmd), BC28_MQTTPUB_CMD, ONET_TOPIC_PROPERTY_POST);
    Bc28_SendCmd(cmd);
    if (Bc28_WaitResponse(">", 2000) == 0) {
        bc28_info.sta.bit.mqtt_pub = 0;
        bc28_info.sta.bit.mqtt_conn = 0;
        return 0;
    }
        
    
    Bc28_SendStr("{\r\n");
    snprintf(cmd, sizeof(cmd), "\t\"id\": \"%d\",\r\n", post_id++);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\"params\": {\r\n");
    Bc28_SendStr("\t\t\"temperature\": {\r\n");
    snprintf(cmd, sizeof(cmd), "\t\t\t\"value\": %d.%d,\r\n", temp/10, temp%10);
    Bc28_SendStr(cmd);
    unix_ms = Rtc_GetUnixTime();
    unix_ms = unix_ms * 1000;
    snprintf(cmd, sizeof(cmd), "\t\t\t\"time\": %llu\r\n", unix_ms);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\t},\r\n");
    Bc28_SendStr("\t\t\"humidity\": {\r\n");
    snprintf(cmd, sizeof(cmd), "\t\t\t\"value\": %u.%u,\r\n", humi/10, humi%10);
    Bc28_SendStr(cmd);
    snprintf(cmd, sizeof(cmd), "\t\t\t\"time\": %llu\r\n", unix_ms);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\t},\r\n");
    Bc28_SendStr("\t\t\"pm25\": {\r\n");
    snprintf(cmd, sizeof(cmd), "\t\t\t\"value\": %u,\r\n", pm25);
    Bc28_SendStr(cmd);
    snprintf(cmd, sizeof(cmd), "\t\t\t\"time\": %llu\r\n", unix_ms);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\t},\r\n");
    
    Bc28_SendStr("\t\t\"lightSta\": {\r\n");
    snprintf(cmd, sizeof(cmd), "\t\t\t\"value\": %s,\r\n", light_GetSta()?"true":"false");
    Bc28_SendStr(cmd);
    snprintf(cmd, sizeof(cmd), "\t\t\t\"time\": %llu\r\n", unix_ms);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\t}\r\n");
    Bc28_SendStr("\t}\r\n");
    Bc28_SendStr("}\r\n");
    Bc28_SendData(&end_chr, 1); /* ���ͽ����ַ� */
    
    Bc28_WaitResponse("+QMTPUB:", 5000);
    BC28_DELAYMS(100);
    At_ClearReceive(); /* ������н��� */
    bc28_info.sta.bit.mqtt_pub = 0;
    
    return 1;
}

/**
 * @description	  : BC28�ϴ��豸��״̬�仯�¼�
 * @param     	  : ��״̬
 * @return 		  : 0ʧ�� 1�ɹ�
 */
uint8_t Bc28_MqttPublishEvent_LightTurn(uint8_t lightSta)
{
    char cmd[100];
    uint64_t unix_ms;
    uint8_t end_chr = 0x1A;
    
    if (bc28_info.sta.bit.mqtt_conn == 0)
        return 0;
    
    bc28_info.sta.bit.mqtt_pub = 1; //��ʼpublish
    snprintf(cmd, sizeof(cmd), BC28_MQTTPUB_CMD, ONET_TOPIC_EVENT_POST);
    Bc28_SendCmd(cmd);
    if (Bc28_WaitResponse(">", 2000) == 0) {
        bc28_info.sta.bit.mqtt_pub = 0;
        bc28_info.sta.bit.mqtt_conn = 0;
        return 0;
    }
    Bc28_SendStr("{\r\n");
    snprintf(cmd, sizeof(cmd), "\t\"id\": \"%d\",\r\n", post_id++);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\"params\": {\r\n");
    Bc28_SendStr("\t\t\"lightTurn\": {\r\n");
    Bc28_SendStr("\t\t\t\"value\":{\r\n");
    snprintf(cmd, sizeof(cmd), "\t\t\t\t\"status\": %s\r\n", lightSta ? "true":"false");
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\t\t},\r\n");
    unix_ms = Rtc_GetUnixTime();
    unix_ms = unix_ms * 1000;
    snprintf(cmd, sizeof(cmd), "\t\t\t\"time\": %llu\r\n", unix_ms);
    Bc28_SendStr(cmd);
    Bc28_SendStr("\t\t}\r\n");
    Bc28_SendStr("\t}\r\n");
    Bc28_SendStr("}\r\n");
    
    Bc28_SendData(&end_chr, 1); /* ���ͽ����ַ� */
    
    Bc28_WaitResponse("+QMTPUB:", 5000);
    BC28_DELAYMS(100);
    At_ClearReceive(); /* ������н��� */
    bc28_info.sta.bit.mqtt_pub = 0;
    
    return 1;
}

/**
 * @description	  : BC28 mqtt���Ľ������ݴ���
 * @param     	  : void
 * @return 		  : void
 */
void Bc28_MqttSubscribe_ReceiveHandler(void)
{
    uint8_t ret;
    char buf[200];
    char *token, *p;
    uint64_t id;
    int32_t code = ONENET_MQTTCODE_THINGERR;
    
    do {
        ret = At_ReadLine(buf, sizeof(buf), 0);
        if (ret) {
            if (strstr(buf, "+QMTSTAT:")) { /* ���ӶϿ����ߴ��� ��Ҫ���³�ʼ�� */
                bc28_info.sta.all = 0;
                bc28_info.sig = 99;
                memset(bc28_info.ip4, 0, 4);
            } else if (strstr(buf, "+QMTRECV:")) { /* ���յ��˶��ĵ�������Ϣ */
                token = strtok(buf, ",");
                token = strtok(NULL, ",");
                token = strtok(NULL, ","); //topic
                if (strcmp(token, "\""ONET_TOPIC_PROPERTY_SET"\"") == 0) {
                    while (token) {
                        token = strtok(NULL, ","); //payload
                        if (strstr(token, "lightSta")) {
                            if (strstr(token, "true")) {
                                LigthCon_BtnSetOn();
                            } else {
                                LigthCon_BtnSetOff();
                            }
                            code = ONENET_MQTTCODE_SUC;
                        } else if (strstr(token, "id")){
                            p = token;
                            while (*p < '0' || *p > '9') { p++; } /* ֱ������ */
                            id = atoll(p);
                        }
                    }
                    Bc28_MqttProSetReply(id, code);
                }
            }
        }
    } while (ret);
}

/**
 * @description	  : BC28��ȡ�ź�ǿ��
 * @param     	  : void
 * @return 		  : void
 */
void Bc28_GetSignalStrong(void)
{
    if (!Bc28_GetCSQ(3, 5000)) {
        bc28_info.sig = 99;
    }
}

/**
 * @description	  : BC28�����ź�ǿ��ֵdBm
 * @param     	  : void
 * @return 		  : 0û�ź� ��������
 */
int16_t Bc28Info_GetSig(void)
{
    int16_t sig;
    
    if (bc28_info.sig == 99) {
        bc28_info.sta.bit.sig = 0;
        return 0;
    } else {
        sig = -113;
        sig = sig + bc28_info.sig * 2;
    }
    return sig;
}

/**
 * @description	  : BC28����ip��ַ
 * @param     	  : void
 * @return 		  : 0��ȡʧ�� 1����
 */
uint8_t Bc28Info_GetIp(uint8_t *ip)
{
    memcpy(ip, bc28_info.ip4, 4);
    return 1;
}

/**
 * @description	  : BC28�����Ƿ����ӳɹ�
 * @param     	  : void
 * @return 		  : 0δ���� 1������
 */
uint8_t Bc28Info_IsConn(void)
{
    if (bc28_info.sta.bit.mqtt_conn)
        return 1;
    return 0;
}
