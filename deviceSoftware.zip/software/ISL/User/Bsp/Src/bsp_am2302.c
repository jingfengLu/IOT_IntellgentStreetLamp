#include "bsp.h"

#define SDA_Pin  GPIO_PIN_7
#define SDA_Port GPIOA

#define SDA_1()  (SDA_Port->BSRR = SDA_Pin)         //�ߵ�ƽ
#define SDA_0()  (SDA_Port->BSRR = SDA_Pin << 16U)  //�͵�ƽ

#define SDA_IN()  {SDA_Port->MODER&=~(3<<(7*2));SDA_Port->MODER|=0<<(7*2);}
#define SDA_OUT() {SDA_Port->MODER&=~(3<<(7*2));SDA_Port->MODER|=1<<(7*2);}

#define SDA_READ()  ((SDA_Port->IDR & SDA_Pin) != 0)	/* ��SDA����״̬ */

#define AM2302_DELAYUS(x)  bsp_DelayUS(x)  //us��ʱ

static uint16_t humi;
static int16_t temp;

/**
 * @description		: Initialize am2302
 * @param 			: void
 * @return 			: void
 */
void bsp_InitAm2302(void)
{					     
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitStruct.Pin = SDA_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(SDA_Port, &GPIO_InitStruct);
    
    SDA_1(); // �ͷ�����
}

/**
 * @description		: �ȴ�SDA��ƽ�ı�
 * @param 			: �ȴ��ĵ�ƽֵ
 * @param 			: ��ʱʱ��
 * @return 			: true�ȴ��ɹ� false�ȴ���ʱ
 */
static _Bool am2302_wait_sda(_Bool val, uint32_t time_us)
{
    do {
        time_us--;
        AM2302_DELAYUS(1);
    } while ((SDA_READ() != val) && time_us);
    if (time_us)
        return TRUE;
    return FALSE;
}

/**
 * @description		: Initialize am2302
 * @param 			: void
 * @return 			: true��ȡ�ɹ� false��ȡʧ��
 */
_Bool am2302_ReadData(void)
{
    uint8_t c = 0, i, sum = 0;
    uint16_t t = 0, h = 0;
    
    SDA_OUT();
    AM2302_DELAYUS(1);
    SDA_0();
    AM2302_DELAYUS(1000);
    SDA_1();
    SDA_IN();
    AM2302_DELAYUS(5);
    if (!am2302_wait_sda(0, 100)) //�ȴ��͵�ƽ
        return FALSE;
    if (!am2302_wait_sda(1, 100)) //�ȴ��ߵ�ƽ
        return FALSE;

    for (i = 0; i < 16; i++) { /* ��ȡʪ�� */
        h <<= 1;
        if (!am2302_wait_sda(0, 100)) //�ȴ��͵�ƽ
            return FALSE;
        if (!am2302_wait_sda(1, 100)) //�ȴ��ߵ�ƽ
            return FALSE;
        AM2302_DELAYUS(40); //�ȴ�50us  �ߵ�ƽ30us��ʾ0 70us��ʾ1
        if (SDA_READ() == 1) {
            h |= 0x01;
        }
    }
    
    for (i = 0; i < 16; i++) { /* ��ȡ�¶� */
        t <<= 1;
        if (!am2302_wait_sda(0, 100)) //�ȴ��͵�ƽ
            return FALSE;
        if (!am2302_wait_sda(1, 100)) //�ȴ��ߵ�ƽ
            return FALSE;
        AM2302_DELAYUS(40); //�ȴ�50us  �ߵ�ƽ30us��ʾ0 70us��ʾ1
        if (SDA_READ() == 1) {
            t |= 0x01;
        }
    }
    
    for (i = 0; i < 8; i++) { /* ��ȡУ��ֵ */
        c <<= 1;
        if (!am2302_wait_sda(0, 100)) //�ȴ��͵�ƽ
            return FALSE;
        if (!am2302_wait_sda(1, 100)) //�ȴ��ߵ�ƽ
            return FALSE;
        AM2302_DELAYUS(40); //�ȴ�50us  �ߵ�ƽ30us��ʾ0 70us��ʾ1
        if (SDA_READ() == 1) {
            c |= 0x01;
        }
    }
    
    if (!am2302_wait_sda(0, 100)) //�ȴ��͵�ƽ
        return FALSE;
    if (!am2302_wait_sda(1, 100)) //�ȴ��ߵ�ƽ
        return FALSE;
    
    SDA_OUT();
        
    sum += (h >> 8) + (h & 0xff);
    sum += (t >> 8) + (t & 0xff);
    if (sum == c) {
        if (t & (1 << 15)) { //��ֵ
            temp = -((int)t & ~(1 << 15));
        } else {
            temp = t;
        }

        humi = h;
    } else return FALSE;
    
    return TRUE;
}

/**
 * @description		: Initialize am2302
 * @param 			: �¶Ȼش�ָ��
 * @param           : ʪ�Ȼش�ָ��
 * @return 			: true��ȡ�ɹ� false��ȡʧ��
 */
void am2302_GetHumiture(int16_t *temperature, uint16_t *humidity)
{
    *temperature = temp;
    *humidity = humi;
}


