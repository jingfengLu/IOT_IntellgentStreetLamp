#include "bsp.h"
#include "cmsis_os2.h"

ADC_HandleTypeDef hadc1;

static uint16_t pm25;

#define adc_DelayUs bsp_DelayUS
#define adc_DelayMs osDelay

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
void bsp_InitAdc1(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};

    /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
    */
    hadc1.Instance = ADC1;
    hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
    hadc1.Init.Resolution = ADC_RESOLUTION_12B;
    hadc1.Init.ScanConvMode = DISABLE;
    hadc1.Init.ContinuousConvMode = DISABLE;
    hadc1.Init.DiscontinuousConvMode = DISABLE;
    hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc1.Init.NbrOfConversion = 1;
    hadc1.Init.DMAContinuousRequests = DISABLE;
    hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    if (HAL_ADC_Init(&hadc1) != HAL_OK)
    {
    Error_Handler();
    }
    /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
    */
    sConfig.Channel = ADC_CHANNEL_0;
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
    if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
    {
    Error_Handler();
    }
}



/**
 * @description : ���һ��ADCת�����
 * @param       : void
 * @return      : adcֵ
 */
static uint16_t adc1_GetData(void)
{
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 10);
    return HAL_ADC_GetValue(&hadc1);
}


/**
 * @description : ���һ��PM2.5������ת�����
 * @param       : void
 * @return      : adcֵ
 */
static uint16_t getPm25Value(void)
{
    uint16_t dat;
    
    PM25LED_ON();
    adc_DelayUs(280); /* 0.28ms */
    dat = adc1_GetData();
    adc_DelayUs(40);
    PM25LED_OFF();
    dat = dat * 3300 / 4096 * 2; /* �����������ѹ ��λmV */
    if (dat > 400) {
        dat -= 400;
        dat = dat / 5;
    } else dat = 0;
    return dat;
}

/**
 * @description : ���һ��PM2.5������ת����� ��ֵ
 * @param       : void
 * @return      : void
 */
void getPm25Average(void)
{
    uint16_t i, average = 0;
    for (i = 0; i < 10; i++) {
        average += getPm25Value();
        adc_DelayMs(10);
    }
    pm25 = average / 10;
}

/**
 * @description : ���ر���
 * @param       : void
 * @return      : pm2.5��ֵ
 */
uint16_t getPm25(void)
{
    return pm25;
}
