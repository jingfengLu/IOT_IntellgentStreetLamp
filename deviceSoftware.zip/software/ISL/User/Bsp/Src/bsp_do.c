#include "bsp.h"

static _Bool light_sta = FALSE;

/**
 * @description		: Initialize DO gpio 
 * @param 			: void
 * @return 			: void
 */
void bsp_InitDo(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* Configure GPIO pins */
    GPIO_InitStruct.Pin = LightEn_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LightEn_Port, &GPIO_InitStruct);
	
    LIGHT_OFF();
    
    /* Configure GPIO pins */
    GPIO_InitStruct.Pin = Pm25Led_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(Pm25Led_Port, &GPIO_InitStruct);
	
    PM25LED_OFF();
    
    
    /* Configure GPIO pins */
    GPIO_InitStruct.Pin = Bc28Rst_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(Bc28Rst_Port, &GPIO_InitStruct);
    
    Bc28Rst_ON();
}

/**
 * @description		: ���õƹ�״̬
 * @param 			: �ƹ�״̬ TRUE�� FALSE��
 * @return 			: void
 */
void light_SetSta(_Bool sta)
{
    light_sta = sta;
    if (light_sta)
        LIGHT_ON();
    else 
        LIGHT_OFF();
}

/**
 * @description		: ���õƹ�״̬
 * @param 			: void
 * @return 			: �ƹ�״̬ TRUE�� FALSE��
 */
_Bool light_GetSta(void)
{
    return light_sta;
}
