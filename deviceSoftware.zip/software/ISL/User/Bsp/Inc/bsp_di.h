#ifndef _BSP_DI_H_
#define _BSP_DI_H_

#define LightCheck_Pin GPIO_PIN_6
#define LightCheck_Port GPIOA
#define LightCheck_Read()  ((LightCheck_Port->IDR & LightCheck_Pin) != 0)	/* ��״̬ */

#define PersonCheck_Pin GPIO_PIN_13
#define PersonCheck_Port GPIOB
#define PersonCheck_Read()  ((PersonCheck_Port->IDR & PersonCheck_Pin) != 0)	/* ��״̬ */


void bsp_InitDi(void);

#endif /* _BSP_DI_H_ */
