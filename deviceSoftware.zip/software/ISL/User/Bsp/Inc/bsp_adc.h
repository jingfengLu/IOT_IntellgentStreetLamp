#ifndef _BSP_ADC_H_
#define _BSP_ADC_H_

void bsp_InitAdc1(void);
void getPm25Average(void);
uint16_t getPm25(void);

#endif /* _BSP_ADC_H_ */
