#ifndef _BSP_UART_H_
#define _BSP_UART_H_
#include "bsp.h"

/* ����˿ں� */
typedef enum
{
	COM1 = 0,	/* USART1 */
	COM2 = 1,	/* USART2 */
    COM3 = 2,	/* USART3 */
	COM4 = 3,	/* UART4 */
	COM5 = 4,	/* UART5 */
	COM6 = 5,	/* USART6 */
	COM7 = 6,	/* UART7 */	
	COM8 = 7	/* UART8 */	
}COM_PORT_E;


void bsp_uartInit(void);

uint8_t comGetChar(COM_PORT_E port, uint8_t *data);
void comSendBuf(COM_PORT_E port, uint8_t *buf, uint16_t len);

#endif
