#ifndef _BSP_IIC_GPIO_H
#define _BSP_IIC_GPIO_H
#include <stdint.h>

void bsp_InitI2C(void);
void I2C1_Start(void);
void I2C1_Stop(void);
uint8_t I2C1_Wait_Ack(void);
void I2C1_Ack(void);
void I2C1_NAck(void);
void I2C1_Send_Byte(uint8_t _ucByte);
uint8_t I2C1_Read_Byte(uint8_t ack);
uint8_t I2C1_CheckDevice(uint8_t _Address);

#endif /* _BSP_IIC_GPIO_H */