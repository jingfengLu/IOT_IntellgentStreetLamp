#ifndef _BSP_DO_H_
#define _BSP_DO_H_

#define LightEn_PIN GPIO_PIN_12
#define LightEn_Port GPIOA
#define LIGHT_ON()    (LightEn_Port->BSRR = LightEn_PIN)         //�ߵ�ƽ
#define LIGHT_OFF()   (LightEn_Port->BSRR = LightEn_PIN << 16U)  //�͵�ƽ


#define Pm25Led_PIN GPIO_PIN_5
#define Pm25Led_Port GPIOA
#define PM25LED_ON()    (Pm25Led_Port->BSRR = Pm25Led_PIN)         //�ߵ�ƽ
#define PM25LED_OFF()   (Pm25Led_Port->BSRR = Pm25Led_PIN << 16U)  //�͵�ƽ

#define Bc28Rst_PIN GPIO_PIN_12
#define Bc28Rst_Port GPIOB
#define Bc28Rst_ON()    (Bc28Rst_Port->BSRR = Bc28Rst_PIN)         //�ߵ�ƽ
#define Bc28Rst_OFF()   (Bc28Rst_Port->BSRR = Bc28Rst_PIN << 16U)  //�͵�ƽ

void bsp_InitDo(void);
void light_SetSta(_Bool sta);
_Bool light_GetSta(void);

#endif /* _BSP_DO_H_ */