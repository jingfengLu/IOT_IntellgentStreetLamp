#ifndef _BSP_LED_H_
#define _BSP_LED_H_

#define LED_RUN_PIN GPIO_PIN_14
#define LED_RUN_GPIO_Port GPIOB

#define LED_RUN_OFF()  (LED_RUN_GPIO_Port->BSRR = LED_RUN_PIN)         //�ߵ�ƽ
#define LED_RUN_ON()   (LED_RUN_GPIO_Port->BSRR = LED_RUN_PIN << 16U)  //�͵�ƽ
#define LED_RUN_REV()  (LED_RUN_GPIO_Port->ODR ^= LED_RUN_PIN)         //ȡ��
 
void bsp_InitLed(void);

#endif /* _BSP_LED_H_ */
