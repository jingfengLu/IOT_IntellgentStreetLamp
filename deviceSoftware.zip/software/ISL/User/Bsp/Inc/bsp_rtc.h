#ifndef _BSP_RTC_H_
#define _BSP_RTC_H_

#include "bsp.h"


typedef struct 
{
	uint8_t  hour;
	uint8_t  min;
	uint8_t  sec;			
	uint8_t  month;
	uint8_t  date;
    uint8_t  week;
	uint16_t year;	
}Calendar_Str;

extern Calendar_Str calendar;

void bsp_InitRtc(void);

void Rtc_GetCalendar(void);
void Rtc_SetCalendar(Calendar_Str *cale);
time_t Rtc_GetUnixTime(void);


#endif
