#include "hmi.h"
#include "includes.h"


/**
 * @description	 : ����UI1��Ļ����ʼ��
 * @param        : ��ťID
 * @param        : ��ť��ǰ״̬
 * @return 		 : void
 */
void Ui1_ScreenInit(uint16_t previous)
{
    if (save_new.light_con.rl_con) {
        SetButtonValue(SET_UIID, Ui1_RlCon_BtnID, BUTTON_ON);
    } else {
        SetButtonValue(SET_UIID, Ui1_RlCon_BtnID, BUTTON_OFF);
    }
    
    if (save_new.light_con.time_con) {
        SetButtonValue(SET_UIID, Ui1_TimeCon_BtnID, BUTTON_ON);
    } else {
        SetButtonValue(SET_UIID, Ui1_TimeCon_BtnID, BUTTON_OFF);
    }
    
    SetTextInt32(SET_UIID, Ui1_BeginTimeHour_TxtID, save_new.light_con.time_begin.hour, 0, 2);
    SetTextInt32(SET_UIID, Ui1_BeginTimemin_TxtID, save_new.light_con.time_begin.min, 0, 2);
    SetTextInt32(SET_UIID, Ui1_FinalTimeHour_TxtID, save_new.light_con.time_final.hour, 0, 2);
    SetTextInt32(SET_UIID, Ui1_FinalTimemin_TxtID, save_new.light_con.time_final.hour, 0, 2);
    
    if (save_new.timing.power_on) {
        SetButtonValue(SET_UIID, Ui1_PowerOnTiming_BtnID, BUTTON_ON);
    } else {
        SetButtonValue(SET_UIID, Ui1_PowerOnTiming_BtnID, BUTTON_OFF);
    }
}

