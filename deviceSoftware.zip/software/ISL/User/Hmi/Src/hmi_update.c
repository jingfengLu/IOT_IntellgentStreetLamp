#include "includes.h"


static void hmi_UnitUpdate_5000ms(void);
static void hmi_UnitUpdate_1000ms(void);
static void hmi_UnitUpdate_100ms(void);


static void hmi_ShowRtcTime(Calendar_Str *cale);

/*! 
*  \brief  ��������
*/ 
void hmi_UpdateDisplay(void)
{
	static uint16_t time_cnt = 0;

    time_cnt++;
    if (time_cnt == 1000) {
        hmi_UnitUpdate_5000ms();
        time_cnt = 0;
    }
	if (time_cnt % 200 == 0) {  /* 1s����һ��ʱ��͵���ֵ���л��涼Ҫ���� */  
        hmi_UnitUpdate_1000ms();
	}
    
    if (time_cnt % 20 == 0) {
        hmi_UnitUpdate_100ms();
    }
}

/**
 * @description		: ��Ļ�Ŀؼ�״̬���� 100ms����һ��
 * @param       	: void
 * @return 			: void
 */
static void hmi_UnitUpdate_100ms(void)
{
//    uint32_t ret_event;
//    
//    ret_event = osEventFlagsWait(Wire_EventFlagId, WIRE_DATA_SUC | WIRE_DATA_FAIL, osFlagsWaitAny, 0);
//    if ((ret_event & (1 << 31)) == 0) {
//    }    
//    
}


    
/**
 * @description		: ��Ļ�Ŀؼ�״̬���� 1000ms����һ��
 * @param       	: void
 * @return 			: void
 */
static void hmi_UnitUpdate_1000ms(void)
{
    uint32_t ret_event;
    
    SetButtonValue(MAIN_UIID, Ui0_TurnLight_BtnID, light_GetSta());
    
    SetButtonValue(MAIN_UIID, Ui0_PersonSta_BtnID, PersonCheck_Read());
    
    hmi_ShowRtcTime(&calendar);
    
    ret_event = osEventFlagsWait(Hmi1_EventFlagId, HMI1_SaveSuc, osFlagsWaitAny, 0);
    if ((ret_event & (1 << 31)) == 0) { /* save���óɹ� */
        SetButtonValue(SET_UIID, Ui1_SetOk_BtnID, BUTTON_OFF);
    }
    ret_event = osEventFlagsWait(Hmi1_EventFlagId, HMI1_GetNtpFinal, osFlagsWaitAny, 0);
    if ((ret_event & (1 << 31)) == 0) { /* ��ʱ���� */
        SetButtonValue(MAIN_UIID, Ui0_GetNTPTime_BtnID, BUTTON_OFF);
    }
    
}

/**
 * @description		: ��Ļ�Ŀؼ�״̬���� 5000ms����һ��
 * @param       	: void
 * @return 			: void
 */
static void hmi_UnitUpdate_5000ms(void)
{
    char str[48];
    uint8_t ip[4];
    uint16_t humi;
    int16_t temp;
    uint32_t ret_event;
    
    snprintf(str, sizeof(str), "PM2.5:%d", getPm25()); /* ����PM2.5��ֵ */
    SetTextValue(MAIN_UIID, Ui0_Pm25Value_TxtID, str);
    
    am2302_GetHumiture(&temp, &humi);
    snprintf(str, sizeof(str), "�¶�:%d.%d��", temp/10, temp%10); /* �����¶ȵ�ֵ */
    SetTextValue(MAIN_UIID, Ui0_TempValue_TxtID, str);
    snprintf(str, sizeof(str), "ʪ��:%d.%d%%", humi/10, humi%10); /* ����ʪ�ȵ�ֵ */
    SetTextValue(MAIN_UIID, Ui0_HumiValue_TxtID, str);
    
    snprintf(str, sizeof(str), "�ź�ǿ��:%ddBm", Bc28Info_GetSig()); /* �ź�ǿ�� */
    SetTextValue(MAIN_UIID, Ui0_NbSigStro_TxtID, str);
    
    Bc28Info_GetIp(ip);
    snprintf(str, sizeof(str), "ip:%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]); /* ip */
    SetTextValue(MAIN_UIID, Ui0_NbIp_TxtID, str);
    
    if (Bc28Info_IsConn()) {
        SetTextValue(MAIN_UIID, Ui0_NbState_TxtID, "״̬:������onenet");
    } else {
        SetTextValue(MAIN_UIID, Ui0_NbState_TxtID, "״̬:δ����");
    }
    
    ret_event = osEventFlagsWait(Hmi1_EventFlagId, HMI1_SoftVer_Update, osFlagsWaitAny, 0);
    if ((ret_event & (1 << 31)) == 0) { /* ���������汾 */
        SetTextValue(MAIN_UIID, Ui0_SoftVer_TxtID, ISL_SOFTWARE_VERSION); //�汾��Ϣ
        SetTextValue(MAIN_UIID, Ui0_DevInfo_TxtID, ISL_DEVINFO); //�豸��Ϣ
    }
}


static void hmi_ShowRtcTime(Calendar_Str *cale)
{
    char str[16];
    
    snprintf(str, sizeof(str), "%d-%d-%d", cale->year, cale->month, cale->date); /* ���� */
    SetTextValue(MAIN_UIID, Ui0_RtcDate_TxtID, str);
    
    snprintf(str, sizeof(str), "%d:%d:%d", cale->hour, cale->min, cale->sec); /* ʱ�� */
    SetTextValue(MAIN_UIID, Ui0_RtcTime_TxtID, str);
}
