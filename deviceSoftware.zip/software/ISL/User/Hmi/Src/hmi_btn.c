#include "hmi.h"
#include "includes.h"

/**
 * @description	 : UI0��button���¶�����������
 * @param        : ��ťID
 * @param        : ��ť��ǰ״̬
 * @return 		 : void
 */
void Ui0_BtnChange(uint16_t btn_id, uint8_t state)
{
    switch (btn_id) {
    case (Ui0_GetNTPTime_BtnID):
        osEventFlagsSet(Hmi1_EventFlagId, HMI1_GetNtpTime);
        break;
    case (Ui0_TurnLight_BtnID):
        if (state)
            LigthCon_BtnSetOn();
        else
            LigthCon_BtnSetOff();
        break;
    case (Ui0_PersonSta_BtnID):
        break;
    }
}


/**
 * @description	 : UI1��button���¶�����������
 * @param        : ��ťID
 * @param        : ��ť��ǰ״̬
 * @return 		 : void
 */
void Ui1_BtnChange(uint16_t btn_id, uint8_t state)
{
    switch (btn_id) {
    case (Ui1_SetExit_BtnID):
        if (state)
            save_reg.set.cancel = 1;
        break;
    case (Ui1_RlCon_BtnID):
        if (state) {
            save_new.light_con.rl_con = 1;
        } else {
            save_new.light_con.rl_con = 0;
        }
        break;
    case (Ui1_TimeCon_BtnID):
        if (state) {
            save_new.light_con.time_con = 1;
        } else {
            save_new.light_con.time_con = 0;
        }
        break;
    case (Ui1_PowerOnTiming_BtnID):
        if (state) {
            save_new.timing.power_on = 1;
        } else {
            save_new.timing.power_on = 0;
        }
        break;
    case (Ui1_SetOk_BtnID):
        if (state)
            save_reg.set.update = 1;
        break;
    }
}
