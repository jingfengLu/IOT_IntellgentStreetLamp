#include "hmi.h"
#include "bsp_rtc.h"


Ui_InfoSta_str ui_info;




static void ProcessMessage(PCTRL_MSG msg, uint16 size);

static void NotifyScreen(uint16_t screen_id);
static void NotifyReadRTC(uint8 year,uint8 month,uint8 week,uint8 day,uint8 hour,uint8 minute,uint8 second);
static void NotifyButton(uint16 screen_id, uint16 control_id, uint8  state);
static void NotifyText(uint16 screen_id, uint16 control_id, uint8 *str);
static void NotifyProgress(uint16 screen_id, uint16 control_id, uint32 value);
static void NotifySlider(uint16 screen_id, uint16 control_id, uint32 value);
static void NotifyMeter(uint16 screen_id, uint16 control_id, uint32 value);
static void NotifyMenu(uint16 screen_id, uint16 control_id, uint8 item, uint8 state);
static void NotifySelector(uint16 screen_id, uint16 control_id, uint8  item);
static void NotifyTimer(uint16 screen_id, uint16 control_id);

static void hmi_ScreenChange(uint16_t previous, uint16_t now);
/**
 * @description		: 读取消息处理
 * @param    	    : void
 * @return 			: void
 */
void hmi_CmdHandle(void)
{
    uint32_t ret_event;
	uint16_t size;
	
	size = queue_find_cmd(ui_info.cmd_buffer, CMD_MAX_SIZE);                             //从缓冲区中获取一条指令         

	if(size>0)                                                                                                                                       
		ProcessMessage((PCTRL_MSG)ui_info.cmd_buffer, size);                             //指令处理 
    

    ret_event = osEventFlagsWait(Hmi1_EventFlagId, HMI1_Screen_Update, osFlagsWaitAny, 0);
    if ((ret_event & (1 << 31)) == 0) {
        hmi_ScreenChange(ui_info.last_screen_id, ui_info.current_screen_id);
    }
}


/**
 * @description		: 消息处理流程
 * @param           : 待处理消息
 * @param           : 消息长度
 * @return 			: void
 */
static void ProcessMessage(PCTRL_MSG msg, uint16 size)
{
    uint8 cmd_type = msg->cmd_type;                                                  //指令类型
    uint8 ctrl_msg = msg->ctrl_msg;                                                  //消息的类型
    uint8 control_type = msg->control_type;                                          //控件类型
    uint16 screen_id = PTR2U16(&msg->screen_id);                                     //画面ID
    uint16 control_id = PTR2U16(&msg->control_id);                                   //控件ID
    uint32 value = PTR2U32(msg->param);                                              //数值
    uint8_t *cmd_buffer = ui_info.cmd_buffer;
    
    switch(cmd_type)
    {
    case NOTIFY_TOUCH_PRESS:                                                        //触摸屏按下
    case NOTIFY_TOUCH_RELEASE:                                                      //触摸屏松开

        break;                                                                    
    case NOTIFY_WRITE_FLASH_OK:                                                     //写FLASH成功

        break;                                                                    
    case NOTIFY_WRITE_FLASH_FAILD:                                                  //写FLASH失败
                                                         
        break;                                                                    
    case NOTIFY_READ_FLASH_OK:                                                      //读取FLASH成功
                                           //去除帧头帧尾
        break;                                                                    
    case NOTIFY_READ_FLASH_FAILD:                                                   //读取FLASH失败
                                                        
        break;                                                                    
    case NOTIFY_READ_RTC:                                                           //读取RTC时间
        NotifyReadRTC(cmd_buffer[2],cmd_buffer[3],cmd_buffer[4],cmd_buffer[5],
                      cmd_buffer[6],cmd_buffer[7],cmd_buffer[8]);
        break;
    case NOTIFY_CONTROL:
        {
            if(ctrl_msg==MSG_GET_CURRENT_SCREEN)                                    //画面ID变化通知
            {
               NotifyScreen(screen_id);                                             //画面切换调动的函数
            }
            else
            {
                switch(control_type)
                {
                case kCtrlButton:                                                   //按钮控件
                    NotifyButton(screen_id,control_id,msg->param[1]);                  
                    break;                                                             
                case kCtrlText:                                                     //文本控件
                    NotifyText(screen_id,control_id,msg->param);                       
                    break;                                                             
                case kCtrlProgress:                                                 //进度条控件
                    NotifyProgress(screen_id,control_id,value);                        
                    break;                                                             
                case kCtrlSlider:                                                   //滑动条控件
                    NotifySlider(screen_id,control_id,value);                          
                    break;                                                             
                case kCtrlMeter:                                                    //仪表控件
                    NotifyMeter(screen_id,control_id,value);                           
                    break;                                                             
                case kCtrlMenu:                                                     //菜单控件
                    NotifyMenu(screen_id,control_id,msg->param[0],msg->param[1]);      
                    break;                                                              
                case kCtrlSelector:                                                 //选择控件
                    NotifySelector(screen_id,control_id,msg->param[0]);                
                    break;                                                              
                case kCtrlRTC:                                                      //倒计时控件
                    NotifyTimer(screen_id,control_id);
                    break;
                default:
                    break;
                }
            } 
            break;  
        } 
    case NOTIFY_HandShake:                                                          //握手通知                                                     
        break;
    default:
        break;
    }
}


/*! 
*  \brief  触摸坐标事件响应
*  \param press 1按下触摸屏，3松开触摸屏
*  \param x x坐标
*  \param y y坐标
*/
void NotifyTouchXY(uint8 press,uint16 x,uint16 y)
{ 
    //TODO: 添加用户代码
}


/*! 
*  \brief    画面切换通知
*  \details  当前画面改变时(或调用GetScreen)，执行此函数
*  \param    screen_id 当前画面ID
*/
void NotifyScreen(uint16_t screen_id)
{
	ui_info.last_screen_id = ui_info.current_screen_id;
    ui_info.current_screen_id = screen_id;               //在工程配置中开启画面切换通知，记录当前画面ID
	osEventFlagsSet(Hmi1_EventFlagId, HMI1_Screen_Update);
}

/*! 
*  \brief 按钮控件通知 当按钮状态改变(或调用GetControlValue)时，执行此函数
*  \param 画面ID
*  \param 控件ID
*  \param 按钮状态：0弹起，1按下
*/
void NotifyButton(uint16 screen_id, uint16 control_id, uint8  state)
{
	switch (screen_id) {  /* 根据屏幕ID来进行按钮动作判断 */
	case MAIN_UIID:
        Ui0_BtnChange(control_id, state);
		break;
    case SET_UIID:
        Ui1_BtnChange(control_id, state);
        break;
	}
}


/*! 
*  \brief  文本控件通知
*  \details  当文本通过键盘更新(或调用GetControlValue)时，执行此函数
*  \details  文本控件的内容以字符串形式下发到MCU，如果文本控件内容是浮点值，
*  \details  则需要在此函数中将下发字符串重新转回浮点值。
*  \param screen_id 画面ID
*  \param control_id 控件ID
*  \param str 文本控件内容
*/
void NotifyText(uint16 screen_id, uint16 control_id, uint8 *str)
{
	switch (screen_id) {
	case (MAIN_UIID):
		break;
    case (SET_UIID):
        Ui1_TxtChange(control_id, str);
		break;
	}
}  


/*! 
*  \brief 读取RTC时间，注意返回的是BCD码
*  \param year 年（BCD）
*  \param month 月（BCD）
*  \param week 星期（BCD）
*  \param day 日（BCD）
*  \param hour 时（BCD）
*  \param minute 分（BCD）
*  \param second 秒（BCD）
*/
void NotifyReadRTC(uint8 year,uint8 month,uint8 week,uint8 day,uint8 hour,uint8 minute,uint8 second)
{
    Calendar_Str cale;
    
    cale.sec    = (0xff & (second>>4))*10 +(0xf & second);    //BCD码转十进制
    cale.year   = (0xff & (year>>4))*10 +(0xf & year) + 2000;                                      
    cale.month  = (0xff & (month>>4))*10 +(0xf & month);
    cale.week   = (0xff & (week>>4))*10 +(0xf & week);                                      
    cale.date   = (0xff & (day>>4))*10 +(0xf & day);
    cale.hour   = (0xff & (hour>>4))*10 +(0xf & hour);
    cale.min    = (0xff & (minute>>4))*10 +(0xf & minute);
    
    Rtc_SetCalendar(&cale);
    
}



/*!                                                                              
*  \brief  进度条控件通知                                                       
*  \details  调用GetControlValue时，执行此函数                                  
*  \param screen_id 画面ID                                                      
*  \param control_id 控件ID                                                     
*  \param value 值                                                              
*/                                                                              
void NotifyProgress(uint16 screen_id, uint16 control_id, uint32 value)           
{  
    //TODO: 添加用户代码   
}   

/*!                                                                              
*  \brief  滑动条控件通知                                                       
*  \details  当滑动条改变(或调用GetControlValue)时，执行此函数                  
*  \param screen_id 画面ID                                                      
*  \param control_id 控件ID                                                     
*  \param value 值                                                              
*/                                                                              
void NotifySlider(uint16 screen_id, uint16 control_id, uint32 value)             
{                                                             
	
}

/*! 
*  \brief  仪表控件通知
*  \details  调用GetControlValue时，执行此函数
*  \param screen_id 画面ID
*  \param control_id 控件ID
*  \param value 值
*/
void NotifyMeter(uint16 screen_id, uint16 control_id, uint32 value)
{
    //TODO: 添加用户代码
}

/*! 
*  \brief  菜单控件通知
*  \details  当菜单项按下或松开时，执行此函数
*  \param screen_id 画面ID
*  \param control_id 控件ID
*  \param item 菜单项索引
*  \param state 按钮状态：0松开，1按下
*/
void NotifyMenu(uint16 screen_id, uint16 control_id, uint8 item, uint8 state)
{
    //TODO: 添加用户代码
    switch (screen_id) {  /* 根据屏幕ID来进行按钮动作判断 */
        
    }
    
}

/*! 
*  \brief  选择控件通知
*  \details  当选择控件变化时，执行此函数
*  \param screen_id 画面ID
*  \param control_id 控件ID
*  \param item 当前选项
*/
void NotifySelector(uint16 screen_id, uint16 control_id, uint8  item)
{

}

/*! 
*  \brief  定时器超时通知处理
*  \param screen_id 画面ID
*  \param control_id 控件ID
*/
void NotifyTimer(uint16 screen_id, uint16 control_id)
{
}

/**
 * @description	  : RGB888 to RGB565
 * @param - r     : red
 * @param - g     : green
 * @param - b     : blue
 * @return 		  : rgb565
 */
uint16_t hmi_Rgb888ToRgb565(uint8_t r, uint8_t g, uint8_t b)
{
	uint16_t rgb565;
	
	rgb565 = ((r & 0b11111000) << 8) | ((g & 0b11111100) << 3) | (b >> 3);
	
	return rgb565;
}

/**
 * @description	  : 重新封装一下画面切换函数
 * @param         : 新的画面ID
 * @return 		  : void
 */
void hmi_SetScreen(uint16 screen_id)
{
    SetScreen(screen_id);
    ui_info.last_screen_id = ui_info.current_screen_id;
    ui_info.current_screen_id = screen_id;
    
    osEventFlagsSet(Hmi1_EventFlagId, HMI1_Screen_Update);
}

/**
 * @description	      : 用于画面切换之后进行数据更新
 * @param             : previous screen
 * @param             : now screen
 * @return 		      : void
 */
static void hmi_ScreenChange(uint16_t previous, uint16_t now)
{
	switch (now) {
	case MAIN_UIID:
		break;
    case SET_UIID:
        Ui1_ScreenInit(previous);
        break;
	}
}

