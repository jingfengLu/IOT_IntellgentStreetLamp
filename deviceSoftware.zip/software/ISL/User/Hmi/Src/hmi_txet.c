#include "hmi.h"
#include "includes.h"

/**
 * @description	 : UI1��text���¶�����������
 * @param        : ��ťID
 * @param        : ��ť��ǰ״̬
 * @return 		 : void
 */
void Ui1_TxtChange(uint16_t txt_id, uint8_t *txt)
{
    switch (txt_id) {
    case (Ui1_BeginTimeHour_TxtID):
        save_new.light_con.time_begin.hour = atoi((char*)txt);
        break;
    case (Ui1_BeginTimemin_TxtID):
        save_new.light_con.time_begin.min = atoi((char*)txt);
        break;
    case (Ui1_FinalTimeHour_TxtID):
        save_new.light_con.time_final.hour = atoi((char*)txt);
        break;
    case (Ui1_FinalTimemin_TxtID):
        save_new.light_con.time_final.min = atoi((char*)txt);
        break;
    }
}
