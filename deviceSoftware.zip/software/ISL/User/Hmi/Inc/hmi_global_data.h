#ifndef _HMI_GLOBAL_DATA_H_
#define _HMI_GLOBAL_DATA_H_

#include "dacai_driver.h"

typedef struct {
    uint8  cmd_buffer[CMD_MAX_SIZE];
    uint16 current_screen_id;
    uint16 last_screen_id;
}Ui_InfoSta_str; /* ����״ָ̬ʾ */


extern Ui_InfoSta_str ui_info;

#endif /* _HMI_GLOBAL_DATA_H_ */