#ifndef  _HMI_H_
#define  _HMI_H_

#include <stdint.h>

#include "hmi_dacai_cmd.h"
#include "hmi_global_data.h"
#include "cmsis_os2.h"

#define BCD2DEC(X) ((X)-((X)>>4)*6)
#define DEC2BCD(X) ((X)+((X)/10)*6)

/* HMI1�¼���־�� */
#define HMI1_Screen_Update         (1 << 0)    /* ������±�־ */
#define HMI1_SoftVer_Update        (1 << 1)    /* ���������汾��ʾ */
#define HMI1_SaveSuc               (1 << 2)    /* ���ø��³ɹ� */
#define HMI1_GetNtpTime            (1 << 3)    /* ��ʱ */
#define HMI1_GetNtpFinal           (1 << 4)    /* ��ʱ���� */

extern osEventFlagsId_t Hmi1_EventFlagId;

void Ui0_BtnChange(uint16_t btn_id, uint8_t state);
void Ui1_BtnChange(uint16_t btn_id, uint8_t state);

void Ui1_ScreenInit(uint16_t previous);

void Ui1_TxtChange(uint16_t txt_id, uint8_t *txt);

#endif /* _HMI_H_ */