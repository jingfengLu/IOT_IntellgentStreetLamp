#ifndef _HMI_DACAI_CMD_H_
#define _HMI_DACAI_CMD_H_

#include "dacai_driver.h"

#define NOTIFY_TOUCH_PRESS         0X01  //触摸屏按下通知
#define NOTIFY_TOUCH_RELEASE       0X03  //触摸屏松开通知
#define NOTIFY_WRITE_FLASH_OK      0X0C  //写FLASH成功
#define NOTIFY_WRITE_FLASH_FAILD   0X0D  //写FLASH失败
#define NOTIFY_READ_FLASH_OK       0X0B  //读FLASH成功
#define NOTIFY_READ_FLASH_FAILD    0X0F  //读FLASH失败
#define NOTIFY_MENU                0X14  //菜单事件通知
#define NOTIFY_TIMER               0X43  //定时器超时通知
#define NOTIFY_CONTROL             0XB1  //控件更新通知
#define NOTIFY_READ_RTC            0XF7  //读取RTC时间
#define MSG_GET_CURRENT_SCREEN     0X01  //画面ID变化通知
#define MSG_GET_DATA               0X11  //控件数据通知
#define NOTIFY_HandShake           0X55  //握手通知

#define PTR2U16(PTR) ((((uint8 *)(PTR))[0]<<8)|((uint8 *)(PTR))[1])  //从缓冲区取16位数据
#define PTR2U32(PTR) ((((uint8 *)(PTR))[0]<<24)|(((uint8 *)(PTR))[1]<<16)|(((uint8 *)(PTR))[2]<<8)|((uint8 *)(PTR))[3])  //从缓冲区取32位数据

/* 按钮状态 */
#define BUTTON_ON    1  //按下
#define BUTTON_OFF   0  //弹起

/************** 画面ID ******************/
#define MAIN_UIID		    0   /* 主界面ID       0 */
#define SET_UIID            1   /* 设置界面ID     1 */

/************** 控件ID ******************/
#define Ui0_RtcDate_TxtID     1
#define Ui0_RtcTime_TxtID     2
#define Ui0_GetNTPTime_BtnID  3
#define Ui0_Pm25Value_TxtID   5
#define Ui0_TempValue_TxtID   6
#define Ui0_HumiValue_TxtID   7
#define Ui0_TurnLight_BtnID   8
#define Ui0_PersonSta_BtnID   9
#define Ui0_SoftVer_TxtID     10
#define Ui0_NbSigStro_TxtID   11
#define Ui0_NbIp_TxtID        12
#define Ui0_NbState_TxtID     13
#define Ui0_DevInfo_TxtID     15

/************** 控件ID ******************/
#define Ui1_SetExit_BtnID        1
#define Ui1_RlCon_BtnID          2
#define Ui1_TimeCon_BtnID        3
#define Ui1_PowerOnTiming_BtnID  4
#define Ui1_BeginTimeHour_TxtID  8
#define Ui1_BeginTimemin_TxtID   10
#define Ui1_FinalTimeHour_TxtID  11
#define Ui1_FinalTimemin_TxtID   13
#define Ui1_SetOk_BtnID          16

enum CtrlType
{
    kCtrlUnknown=0x0,
    kCtrlButton=0x10,                     //按钮
    kCtrlText,                            //文本
    kCtrlProgress,                        //进度条
    kCtrlSlider,                          //滑动条
    kCtrlMeter,                            //仪表
    kCtrlDropList,                        //下拉列表
    kCtrlAnimation,                       //动画
    kCtrlRTC,                             //时间显示
    kCtrlGraph,                           //曲线图控件
    kCtrlTable,                           //表格控件
    kCtrlMenu,                            //菜单控件
    kCtrlSelector,                        //选择控件
    kCtrlQRCode,                          //二维码
};

#pragma pack(push)
#pragma pack(1)                           //按字节对齐

typedef struct
{
    uint8    cmd_head;                    //帧头

    uint8    cmd_type;                    //命令类型(UPDATE_CONTROL)    
    uint8    ctrl_msg;                    //CtrlMsgType-指示消息的类型
    uint16   screen_id;                   //产生消息的画面ID
    uint16   control_id;                  //产生消息的控件ID
    uint8    control_type;                //控件类型

    uint8    param[256];                  //可变长度参数，最多256个字节

    uint8  cmd_tail[4];                   //帧尾
}CTRL_MSG,*PCTRL_MSG;

#pragma pack(pop)


void hmi_CmdHandle(void);
void hmi_UpdateDisplay(void);

uint16_t hmi_Rgb888ToRgb565(uint8_t r, uint8_t g, uint8_t b);
void hmi_SetScreen(uint16_t screen_id);

#endif /* _HMI_DACAI_CMD_H_ */
