#include "cjson_utils.h"
#include "cJSON.h"
#include "includes.h"


/**
 * @description	  : ��ʼ��CJSON ���Լ����ڴ������������ԭʼ���ڴ��������
 * @param     	  : void
 * @return 		  : void
 */
void Cjson_Init(void)
{
    cJSON_Hooks hooks;
    
    hooks.malloc_fn = Mem_Malloc;
    hooks.free_fn = Mem_Free;
    cJSON_InitHooks(&hooks);
}

/**
 * @description	  : �ͷ����ɵ�json����
 * @param     	  : void
 * @return 		  : void
 */
void Cjson_Free(void *addr)
{
    cJSON_free(addr);
}

/**
 * @description	  : ��������װ��onenet����ʹ�õ������ϱ�json����
 * @param     	  : ��Ϣid
 * @param     	  : �¶�
 * @param     	  : ʪ��
 * @param     	  : pm2.5
 * @return 		  : void
 */
char* Cjson_Onenet_Params_CreateJson(uint32_t msg_id, float temp, float humi, uint16_t pm25)
{
    char id[16];
    time_t sec;
    char *string = NULL;
    cJSON *msg = NULL;
    cJSON *params = NULL;
    cJSON *param = NULL;
    cJSON *time = NULL;
    cJSON *t = NULL;
    cJSON *h = NULL;
    
    
    snprintf(id, sizeof(id), "%d", msg_id);
    sec = Rtc_GetUnixTime();
    
    cJSON *monitor = cJSON_CreateObject();
    if (monitor == NULL)
        goto end;
    
    msg = cJSON_CreateString(id); /* msg_id */
    if (msg == NULL)
        goto end;
    cJSON_AddItemToObject(monitor, "id", msg);
    
    params = cJSON_CreateArray();
    if (params == NULL)
        goto end;
    cJSON_AddItemToObject(monitor, "params", params);
    
    param = cJSON_CreateObject();
    if (param == NULL)
        goto end;
    cJSON_AddItemToArray(params, param);
    
    t = cJSON_CreateNumber(temp);
    if (t == NULL)
        goto end;
    cJSON_AddItemToObject(param, "temperature", t);
    
    time = cJSON_CreateNumber(sec);
    if (time == NULL)
        goto end;
    cJSON_AddItemToObject(param, "time", time);
    
    end:
    cJSON_Delete(monitor);
    return string;
}

