#ifndef _CJSON_H_
#define _CJSON_H_

#include <stdint.h>

void Cjson_Init(void);


#endif /* _CJSON_H_ */
