#include "includes.h"

static uint8_t light_con_btnset;

/**
 * @description		: �ƹ���ƴ�������
 * @param       	: void
 * @return 			: void
 */
void LigthCon_Handler(void)
{
    static uint8_t light_cnt = 0, cnt = 0, light_on;
    static uint8_t time_on = 0;
    uint16_t t_f, t_b, t_n;
    
    cnt++;
    if (LightCheck_Read() ) {
        light_cnt++;
    }
    if (cnt == 100) { /* 2s */
        cnt = 0;
        if (light_cnt >= 50 && save_old.light_con.rl_con)
            light_on = 1;
        else 
            light_on = 0;
        
        light_cnt = 0;
        
        if (save_old.light_con.time_con) {
            t_f = save_old.light_con.time_final.hour << 8 | save_old.light_con.time_final.min;
            t_b = save_old.light_con.time_begin.hour << 8 | save_old.light_con.time_begin.min;
            t_n = calendar.hour << 8 | calendar.min;
            if (t_n >= t_f && t_n < t_b) {
                time_on = 0;
            } else time_on = 1;
        } else time_on = 0;
    }
    
    if (light_on || time_on || light_con_btnset) {
        if (light_GetSta() != TRUE) {
            light_SetSta(TRUE);
            osEventFlagsSet(Comm1_EventFlagId, COMM1_LightTurn_Bit);
        }
    } else {
        if (light_GetSta() != FALSE) {
            light_SetSta(FALSE);
            osEventFlagsSet(Comm1_EventFlagId, COMM1_LightTurn_Bit);
        }
    }
    
}

/**
 * @description		: �ƹ���ư�ť����ON
 * @param       	: void
 * @return 			: void
 */
inline void LigthCon_BtnSetOn(void)
{
    light_con_btnset = TRUE;
}

/**
 * @description		: �ƹ���ư�ť����OFF
 * @param       	: void
 * @return 			: void
 */
inline void LigthCon_BtnSetOff(void)
{
    light_con_btnset = FALSE;
}
