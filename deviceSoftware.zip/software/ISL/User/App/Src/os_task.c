#include "includes.h"


/* �߳������� */
void AppTaskStart(void *argument);
void AppTaskHmi(void *argument);
void AppTaskNbiot(void *argument);

/* ��ʱ���ص����� */
void HumitureTimer_Callback(void *argument);


/* ������������� */
const osThreadAttr_t ThreadStart_Attr = 
{
	/* δʹ�� */
//	.cb_mem = &worker_thread_tcb_1,
//	.cb_size = sizeof(worker_thread_tcb_1),
//	.stack_mem = &worker_thread_stk_1[0],
//	.stack_size = sizeof(worker_thread_stk_1),
//	.priority = osPriorityAboveNormal,
//	.tz_module = 0
	
	.name = "osRtxStartThread",
	.attr_bits = osThreadDetached, 
	.priority = osPriorityLow,      /* �� */
	.stack_size = 2048,
};

const osThreadAttr_t ThreadHmi_Attr = 
{
	.name = "osRtxHmiThread",
	.attr_bits = osThreadDetached, 
	.priority = osPriorityBelowNormal,       /* ��0 */
	.stack_size = 2048,
};

const osThreadAttr_t ThreadNbiot_Attr = 
{
	.name = "osRtxNbiotThread",
	.attr_bits = osThreadDetached, 
	.priority = osPriorityBelowNormal1,       /* ��1 */
	.stack_size = 2048,
};

/***** ������ *****/
const osMutexAttr_t HmiUartMutex_Attr = 
{
	.name = "hmi_uart",
	.attr_bits = osMutexRecursive | osMutexPrioInherit,
	NULL,
	0
};


/* �¼���־�� */
const osEventFlagsAttr_t osEventFlagAttr_Hmi1 = 
{
    .name = "hmi1",
    .attr_bits = 0,
    .cb_mem = NULL,
    .cb_size = 0
};
const osEventFlagsAttr_t osEventFlagAttr_Comm1 = 
{
    .name = "Comm1",
    .attr_bits = 0,
    .cb_mem = NULL,
    .cb_size = 0
};

/**** ������ʱ�� ****/
const osTimerAttr_t HumitureTimer_Attr = {
    .name = "Humiture",
    .attr_bits = 0,
    .cb_mem = NULL,
    .cb_size = 0
};

/* �߳�ID */
osThreadId_t ThreadIdStart = NULL;
osThreadId_t ThreadIdHmi = NULL;
osThreadId_t ThreadIdNbiot = NULL;

/* �ź���ID */
osSemaphoreId_t HmiRecCmd_Semaphore = NULL;
osSemaphoreId_t AtRec_Semaphore = NULL;

/* ������ID */
osMutexId_t HmiUart_MutexId = NULL;

/* �¼���־��ID */
osEventFlagsId_t Hmi1_EventFlagId = NULL;
osEventFlagsId_t Comm1_EventFlagId = NULL;

/* ������ʱ��ID */
osTimerId_t HumitureTimerId = NULL;


/**
 * @description		: ��ʼ���񴴽�������֮�����Դ����Ϊ�ͼ�����������
 */
void AppTaskStart(void *argument)
{
	uint8_t led_cnt = 0, pm25_cnt = 0;
	
	/* ��ʼ������ */
	HAL_ResumeTick();
    
    bsp_InitDWT();
    bsp_InitLed();
    bsp_uartInit();
    bsp_InitDo();
    bsp_InitDi();
    
    bsp_InitAdc1();
    bsp_InitAm2302();
    bsp_InitRtc();
    
    Save_Init();
    
    #if Enable_EventRecorder == 1
	/* ��ʼ��EventRecorder������ */
	EventRecorderInitialize(EventRecordAll, 1U);
	EventRecorderStart();
	#endif
    
    /*�����ź��� */
	HmiRecCmd_Semaphore = osSemaphoreNew (30, 0, NULL);
	if (HmiRecCmd_Semaphore == NULL) {
		printf_debug("HmiRecCmd semaphore build failed");
	}
    AtRec_Semaphore = osSemaphoreNew (30, 0, NULL);
	if (AtRec_Semaphore == NULL) {
		printf_debug("AtRec semaphore build failed");
	}
    
    /* ������ */
    HmiUart_MutexId = osMutexNew(&HmiUartMutex_Attr);
	if (HmiUart_MutexId == NULL) {
		printf_debug("HmiUart mutex build failed\r\n");
	}
    
    /* �����¼���־�� */
    Hmi1_EventFlagId = osEventFlagsNew(&osEventFlagAttr_Hmi1);
    if (Hmi1_EventFlagId == NULL) {
		printf_debug("Hmi1 event flag build failed\r\n");
	}
    Comm1_EventFlagId = osEventFlagsNew(&osEventFlagAttr_Comm1);
    if (Comm1_EventFlagId == NULL) {
		printf_debug("Comm1 event flag build failed\r\n");
	}
    
    /* ������ʱ�� */
    HumitureTimerId = osTimerNew(HumitureTimer_Callback, osTimerPeriodic, NULL, &HumitureTimer_Attr);
    if (HumitureTimerId == NULL) {
		printf_debug("Humiture Timer build failed\r\n");
	}
    
	/*�������� */
	ThreadIdHmi = osThreadNew(AppTaskHmi, NULL, &ThreadHmi_Attr); 
    ThreadIdNbiot = osThreadNew(AppTaskNbiot, NULL, &ThreadNbiot_Attr); 
    
    if (HumitureTimerId)
        osTimerStart(HumitureTimerId, HUMITURE_PERIOD); /* ��ʪ�Ȳ���ʱ���� */
    
	while(1) {
		led_cnt++;
        if (led_cnt == 50) {
            Rtc_GetCalendar();
            LED_RUN_REV();
            led_cnt = 0;
        }
        
        pm25_cnt++;
        if (pm25_cnt == 150) {
            getPm25Average();
        }
        LigthCon_Handler();
        Save_DataHandler();
		osDelay(20);
	}
}

/**
 * @description		: ����hmi��ص�����
 */
void AppTaskHmi(void *argument)
{
    osStatus_t ret_os;
    
    osEventFlagsSet(Hmi1_EventFlagId, HMI1_SoftVer_Update);
	while (1) {
        ret_os = osSemaphoreAcquire(HmiRecCmd_Semaphore, 5);
        if (ret_os == osOK)
            hmi_CmdHandle();
        hmi_UpdateDisplay();
//		osDelay(5);
	}
}


/**
 * @description		: ����NBIOT��ص�����
 */
void AppTaskNbiot(void *argument)
{
    uint16_t humi, pm25;
    int16_t temp;
    uint32_t ret_event, i = 0;
    
    init:
    Bc28_Init();
    
    while (1) {
        osDelay(100);
        i++;
        if (i % 180 == 0) {
            Bc28_GetSignalStrong();
        }
        if (i == 50) { /* 5s�ϴ�һ������ */
            i = 0;
            am2302_GetHumiture(&temp, &humi);
            pm25 = getPm25();
            Bc28_MqttPublish_PropertyPost(temp, humi, pm25);
        }
        Bc28_MqttSubscribe_ReceiveHandler();
        if (!Bc28_IsNormal()) {
            i = 0;
            goto init;
        }
        
        ret_event = osEventFlagsWait(Hmi1_EventFlagId, HMI1_GetNtpTime, osFlagsWaitAny, 0);
        if ((ret_event & (1 << 31)) == 0) { /* ��ʱ */
            Bc28_GetNtpTime();
            osEventFlagsSet(Hmi1_EventFlagId, HMI1_GetNtpFinal);
        }
        
        ret_event = osEventFlagsWait(Comm1_EventFlagId, COMM1_LightTurn_Bit, osFlagsWaitAny, 0);
        if ((ret_event & (1 << 31)) == 0) { /* ��״̬�ı� */
            Bc28_MqttPublishEvent_LightTurn(light_GetSta());
        }
    }
}

/**
 * @description		: Humiture������ʱ���ص�����
 */
void HumitureTimer_Callback(void *argument)
{
    am2302_ReadData();
}
