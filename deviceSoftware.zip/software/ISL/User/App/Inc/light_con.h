#ifndef  _LIGHT_CON_H_
#define  _LIGHT_CON_H_


void LigthCon_Handler(void);
void LigthCon_BtnSetOn(void);
void LigthCon_BtnSetOff(void);


#endif /* _LIGHT_CON_H_ */