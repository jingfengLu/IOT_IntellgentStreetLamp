#ifndef _MALLOC_UTILS_H_
#define _MALLOC_UTILS_H_

#include <stdint.h>
#include <string.h>

uint8_t Mem_MallocInit(void);
void* Mem_Malloc(size_t want_size);
void* Mem_Aligned_Alloc(size_t align_size, size_t want_size);
void* Mem_Realloc(void* src_addr, size_t want_size);
void Mem_Free(void* addr);

#endif /* _MALLOC_UTILS_H_ */