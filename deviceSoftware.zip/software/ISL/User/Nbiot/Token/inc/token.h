#ifndef _TOKEN_H_
#define _TOKEN_H_

#include <stdio.h>
#include <string.h>

unsigned char Token_Authorization(char *ver, char *res, unsigned int et, \
              char *access_key, char *authorization_buf, unsigned short authorization_buf_len);

#endif /* _TOKEN_H_ */